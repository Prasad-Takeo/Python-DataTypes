# """
# python Data types
#
# Numeric
#     Integer
#     Float
#     Complex Number
# Dictionary
# Boolean
# Set
# Sequence Type
#    strings
#    list
#    tuple
# """
#
#Numeric
#int, float, complex
print(type(5))
print(type(16.00009234234))
c = 2 + 4j
print(type(c))
#
#Sequence Types
#strings
name = "bootcamp"
description = """this bootcamp is for the software engineering
development using python,flask"""
print(name,description)
#
# #Accessing elements of string
# """
# b  o  o  t  c  a  m  p
# 0  1  2  3  4  5  6  7
# -7 -6 -5  -4  -3  -2 -1
# """
print(name[7])
print(name[-1])
#
# # name[4] = "r"
#
# #string slicing - which will have three arguments start, stop, step
# #inclusive of start index, exclusive of stop index and default step of 1
print(name[4:8:1])
print(name[4:8])
#
print(name[-4:0:1])
#
numbers = "0123456789"
print(len(numbers))
print(numbers[0:len(numbers):2])
#
# #reverse of a string
s = "palindrome"
print(s[::-1])

#string is immutable - once assigned cannot be changed
string1 = "Welcome to the bootcamp"
# string1[2] = "E"

#update entire string
string1 = "WElcome to the bootcamp"

# escape sequencing in string
# I'm here attending my course
string1  = '''I'm fine'''
print(string1)

string1 = 'I\'m fine'
print(string1)

string1 = "I'm \"fine\""
print(string1)

string1 = "C:\\Users\\Python"
print(string1)

string1 = "This is \x48\x45\x58 string"
print(string1)

string1 = r"This is \x48\x45\x58 string"
print(string1)

#string formatting
string1 = "{} {} {}".format("Hello, ","Team", "Welcome")
print(string1)

string1 = "{2} {1} {0}".format(", Hello","Team", "Welcome")
print(string1)

string1 = "{hello} {team} {welcome} {test1}".format(hello="hello, ",
                                            team="team",
                                            welcome="welcome",
                                            test1="test1")
print(string1)

message1 = "Hi, "
message2 = "team"
message3 = "welcome"
string1 = f"{message1} {message2} {message3}"
print(string1)

name = input("enter your name: ")
age = input("enter your age: ")
output = f"The given name is {name} and age is {age}"
print(output)

# formatting of integers
string1 = "{0:b}".format(16)
print(string1)


string1 = "{0:e}".format(22/7)
print(string1)
print(22/7)

string1 = "{0:.2f}".format(22/7)
print(string1)

# default functions in string
string1 = "123"
print(string1.lower())
print(string1.upper())
print(string1.capitalize())
print(string1.isalpha())
print(string1.isalnum())
print(string1.isdigit())

print(len(string1))

# split
# sep, split-count
s = "This is the first week of my course"
print(s.split(" "))

print(s.rsplit(" ",0))
print(s.rsplit(" ",1))
print(s.rsplit(" ",2))

# strip
string1 = "###This is my strip sentence###"
print(string1.strip("#"))
print(string1.lstrip("#"))
print(string1.rstrip("#"))

# join
string1 = "This is the first week of my course"
splitted_string = string1.split()
print(splitted_string)
print(" ".join(splitted_string[0:4]) + "_".join(splitted_string[4:6]) + " ".join(splitted_string[6:]))


# replace
string1 = "This is the first week first week first week of my course"
print(id(string1))
modified_string = string1.replace("first week", "first_week",2)
print(id(modified_string))
print(modified_string)

a = 8
print(id(a))
a = a+2
print(id(a))

l1=[1,2,4]
print(id(l1))
print(l1)
l1.append(5)
print(id(l1))
print(l1)

# use dir(<string_variable>) and try out all the functions in it - task



